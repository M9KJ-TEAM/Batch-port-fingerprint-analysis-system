#批量自动化指纹识别系统
# from judge_port import scan_port
need -> ipaddr,port
# from judge_ssl import scan_ssl
need -> url for example blog.aq-sec.com
# from judge_title import scan_title
need -> addr for example http://blog.aq-sec.com
# from judge_fingerprint import scan_finger
need -> ipaddr,port 

# 扫描流程

**传入参数IP+端口**

**1.进行端口判断**

**2.然后进行指纹识别**

**3.进行ssl判断**

**4.进行title提取**
